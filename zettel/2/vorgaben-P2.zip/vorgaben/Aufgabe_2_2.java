public class Aufgabe_2_2 {

    
    public static void main(String[] args){
        
  
    }
    
}
