public class Aufgabe_2_3{
    // Aufgabenteil (a)
    // 3 4 6 9 13 18 24 ...
    // Schema: 
    public static void folge_a() {
        
    }

    // Aufgabenteil (b)
    // 4 5 3 6 7 5 8 9 ...
    // Schema:
    public static void folge_b() {
        
    }
    
    // Aufgabenteil (c)
    // 3 4 6 3 7 12 6
    // Schema:
    public static void folge_c() {
        
    }

    
    public static void main(String[] args){
        System.out.println("Aufgabenteil (a)");
        folge_a();  // erste Folge berechnen und ausgeben
        System.out.println("\nAufgabenteil (b)");
        folge_b();  // zweite Folge berechnen und ausgeben
        System.out.println("\nAufgabenteil (c)");
        folge_c();  // dritte Folge berechnen und ausgeben
        System.out.println();
    }


}
